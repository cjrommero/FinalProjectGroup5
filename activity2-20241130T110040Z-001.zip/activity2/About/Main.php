<html>
<head>
    <meta charset="UTF-8"/>
    <meta http-equiv="Access-Control-Allow-Origin" content="*">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleabout.css">
    <title>BSIT 3L</title>
</head>
<body>
    <div class="topnav" id="myTopnav">
  <a href="http://localhost/activity2/About/login1.php" class="active"><img src="logo.jpg"></a>
  <a href="javascript:alert('Report Is not been Added so chill and check our website while were working on this');">Report</a>
  <div class="dropdown">
    <button class="dropbtn">Contact Us On Social Media
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="https://www.facebook.com/richie.cabantog.5">Facebook</a>
      <a href="https://www.instagram.com/chiechi32/">Instagram</a>
      <a href="https://github.com/pichie22">Github</a>
    </div>
  </div> 
  <a href="\activity2\Main\main.html">Home</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>

    <h1>BSIT_3L Group 5</h1>
    <div class="container">
        <a href="p1.htm"><img src="img1.jpg"></a>
        <a href="p2.html"><img src="img2.jpg"></a>
        <a href="p3.html"><img src="img3.jpg"></a>
        <a href="p4.html"><img src="img4.jpg"></a>
        <a href="p5.html"><img src="img5.jpg"></a>
        <a href="p6.html"><img src="img6.jpg"></a>
    </div>

    
    
    <div class="hide"><p>Pick a Group 5 Member</p></div>
    <script>
  
  
        function myFunction() {
          var x = document.getElementById("myTopnav");
          if (x.className === "topnav") {
            x.className += " responsive";
          } else {
            x.className = "topnav";
          }
        }
        </script>
</body>


</html>